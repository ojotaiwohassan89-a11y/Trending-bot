"""
EMPIRE Telegram menu add-on
For python-telegram-bot v20+.

Add your video to the same folder as bot.py and name it: menu.mp4
Then import and call send_empire_menu(update, context) from your existing /start
handler. See README.txt inside the ZIP.
"""

from pathlib import Path
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

VIDEO_PATH = Path(__file__).with_name("menu.mp4")

# Edit these entries to match your exact services and prices.
SERVICES = {
    "Trending Services": [
        "Service details and prices: add your confirmed packages here."
    ],
    "DEX Reactions": [
        "Service details and prices: add your confirmed packages here."
    ],
    "Volume Bots": [
        "Service details and prices: add your confirmed packages here."
    ],
    "Bundler Bot": [
        "Service details and prices: add your confirmed packages here."
    ],
}

def _keyboard():
    rows = [
        [InlineKeyboardButton("📈 Trending Services", callback_data="empire:trending")],
        [InlineKeyboardButton("💬 DEX Reactions", callback_data="empire:dex")],
        [InlineKeyboardButton("📊 Volume Bots", callback_data="empire:volume")],
        [InlineKeyboardButton("⚡ Bundler Bot", callback_data="empire:bundler")],
        [InlineKeyboardButton("🧾 My Orders", callback_data="empire:orders")],
        [InlineKeyboardButton("ℹ️ How it works", callback_data="empire:how")],
    ]
    return InlineKeyboardMarkup(rows)

async def send_empire_menu(update, context):
    """Call this inside your existing /start handler."""
    chat = update.effective_chat
    if chat is None:
        return

    caption = (
        "Welcome! Choose a service below to view its details.\\n\\n"
        "Select a category to continue."
    )

    if VIDEO_PATH.is_file():
        with VIDEO_PATH.open("rb") as video:
            await context.bot.send_video(
                chat_id=chat.id,
                video=video,
                caption=caption,
                reply_markup=_keyboard(),
                supports_streaming=True,
            )
    else:
        await context.bot.send_message(
            chat_id=chat.id,
            text=caption + "\\n\\n(Video not found. Upload menu.mp4 beside bot.py.)",
            reply_markup=_keyboard(),
        )

async def empire_menu_callback(update, context):
    """Register this callback handler in your application."""
    query = update.callback_query
    await query.answer()
    key = query.data.split(":", 1)[1]

    if key == "orders":
        await query.message.reply_text("Your orders will appear here through your existing order system.")
        return
    if key == "how":
        await query.message.reply_text(
            "1. Choose a service.\\n"
            "2. Confirm the package and payment instructions.\\n"
            "3. Submit your transaction hash.\\n"
            "4. Wait for admin review."
        )
        return

    category_map = {
        "trending": "Trending Services",
        "dex": "DEX Reactions",
        "volume": "Volume Bots",
        "bundler": "Bundler Bot",
    }
    category = category_map.get(key)
    if not category:
        return

    details = "\\n".join(f"• {item}" for item in SERVICES[category])
    await query.message.reply_text(f"{category}\\n\\n{details}")

