EMPIRE MENU ADD-ON — SETUP

FILES
- empire_menu_addon.py: separate menu module
- menu.mp4: your video file (you add this yourself)

IMPORTANT
Uploading this ZIP or the Python file alone does NOT change your bot.
Your existing bot.py must import and call the add-on. Do not delete or replace
your existing bot.py.

SETUP
1. Extract this ZIP.
2. Upload empire_menu_addon.py to the same GitHub folder as bot.py.
3. Upload your video to that same folder and name it exactly: menu.mp4
4. In your existing bot.py, add this import near the other imports:

   from empire_menu_addon import send_empire_menu, empire_menu_callback

5. Find your existing /start function. Inside it, call:

   await send_empire_menu(update, context)

   Replace the old welcome/menu sending lines in that /start function with this
   call, but keep any important existing setup code.

6. Register the callback handler where the Telegram Application is built:

   from telegram.ext import CallbackQueryHandler
   application.add_handler(CallbackQueryHandler(empire_menu_callback, pattern=r"^empire:"))

7. Commit the changes and redeploy.

SERVICE DETAILS
Open empire_menu_addon.py and edit the SERVICES dictionary with your real
service descriptions and confirmed prices. No prices are invented in this file.

VIDEO
The bot reads menu.mp4 from the same folder as empire_menu_addon.py.
Keep the video reasonably small so Telegram hosting/deployment stays practical.

COMPATIBILITY
This add-on is written for python-telegram-bot v20 or newer (async handlers).
If your current bot uses a different Telegram library or older version, do not
paste these integration lines until the bot's library/version is checked.
